package Chart;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;

import javax.swing.JFrame;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.StandardChartTheme;
import org.jfree.chart.axis.ValueAxis;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class IP0Chart extends ChartPanel implements Runnable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static XYSeries xySeries;
	private String path = "";
	
	public IP0Chart(String path) {
		super(createChart());
		this.path = path;
		StandardChartTheme standardChartTheme = new StandardChartTheme("CN");
		standardChartTheme.setExtraLargeFont(new Font("微软雅黑", Font.BOLD, 20));
		standardChartTheme.setRegularFont(new Font("微软雅黑", Font.PLAIN, 15));
		standardChartTheme.setLargeFont(new Font("微软雅黑", Font.PLAIN, 15));
		standardChartTheme.setSmallFont(new Font("微软雅黑", Font.PLAIN, 10));
		ChartFactory.setChartTheme(standardChartTheme);

		JFrame frame = new JFrame("IP2折线图");// 创建Frame框架并命名
		frame.getContentPane().add(this, new BorderLayout().CENTER);
		frame.pack();
		frame.setVisible(true);
		new Thread(this).start();
		frame.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent windowevent) {
				//System.exit(0);
			}
		});
	}

	// 添加折线
	private static JFreeChart createChart() {
		xySeries = new XYSeries("600℃");
		// xySeries2 = new XYSeries("800℃");
		XYSeriesCollection xyseriescollection = new XYSeriesCollection(xySeries);
		// xyseriescollection.addSeries(xySeries2);
		JFreeChart jfreechart = ChartFactory.createXYLineChart("IP0", "Voltage(V)", "IP0(mA)", xyseriescollection,
				PlotOrientation.VERTICAL, true, true, false);
		ValueAxis valueaxis = jfreechart.getXYPlot().getDomainAxis();
		valueaxis.setAutoRange(true);
		valueaxis.setFixedAutoRange(5D);
		return jfreechart;
	}

	// 线程执行V/mA的数据
	@Override
	public void run() {
		//String path = "E:\\data.xls";
		Workbook excel;
		try {
			excel = Workbook.getWorkbook(new File(path));
			Sheet sheet = excel.getSheet(0);
			int rows = sheet.getRows();
			// 从(0,0)开始
			xySeries.add(0, 0);
			// 遍历提取数据
			for (int i = 1; i < rows; i++) {
				Thread.sleep(1000);
				xySeries.add(Double.parseDouble(sheet.getCell(0, i).getContents().trim()),
						Double.parseDouble(sheet.getCell(1, i).getContents().trim()));
				// xySeries.add(i, i);
			}
		} catch (BiffException e1) {
			e1.printStackTrace();
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}
