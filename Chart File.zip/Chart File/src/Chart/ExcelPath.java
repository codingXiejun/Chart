package Chart;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;




public class ExcelPath extends JFrame implements ActionListener {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String path = "";
	JPanel p;
	JTextField textfield;
	JButton Select, btnConfirm;
	JComboBox<String> menu;
	JFileChooser fc = new JFileChooser();

	public ExcelPath() {
		p = new JPanel(); // 建立一个面板
		this.getContentPane().add(p);// 把面板添加到框架

		textfield = new JTextField(10);
		textfield.setSize(100, 20);
		p.add(textfield); // 把一个文本框添加到面板

		Select = new JButton("浏览");
		p.add(Select); // 把一个浏览按钮添加到面板
		Select.addActionListener(this);

		String[] Strings = { "IP0", "IP1", "IP2" };
		menu = new JComboBox<>(Strings);
		menu.setSize(200, 200);
		menu.setBackground(new Color(Integer.parseInt("ffffff", 16)));
		p.add(menu);
		menu.addActionListener(this);

		btnConfirm = new JButton("确定");
		p.add(btnConfirm);
		btnConfirm.addActionListener(this);
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == Select) {
			int intRetVal = fc.showOpenDialog(this);
			if (intRetVal == JFileChooser.APPROVE_OPTION) {
				textfield.setText(fc.getSelectedFile().getPath());
				path = fc.getSelectedFile().getPath();

			}
		} else if (e.getSource() == btnConfirm) {
			switch (menu.getSelectedItem().toString()) {
			case "IP0":
				new IP0Chart(path);
				break;
			case "IP1":
				new IP1Chart(path);
				break;
			default:
				new IP2Chart(path);
				break;
			}
		}
	}

	public static void main(String[] args) {
		ExcelPath frame = new ExcelPath();
		frame.setSize(400, 100);
		frame.setLocationRelativeTo(null);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setVisible(true);
	}

}
